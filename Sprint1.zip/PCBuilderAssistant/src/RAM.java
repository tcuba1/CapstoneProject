public class RAM extends Part {
    
}
