public class CoolingSystem extends Part {
    
}
