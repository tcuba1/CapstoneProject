public class PowerSupply extends Part {
    
}
