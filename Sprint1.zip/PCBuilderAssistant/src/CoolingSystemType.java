public enum CoolingSystemType {
    
    AIR, AIOLiquidCooling;

}
