public class GPU extends Part {
    //Variables
    Graphics GPUGraphicsRating;

    //Constructor
    public GPU(String partName, int partPrice, Graphics GPUGraphicsRating) {
        super(partName, partPrice);
        this.GPUGraphicsRating = GPUGraphicsRating;
    }

    //Getter method
    public Graphics getGPUGraphicsRating() {
        return GPUGraphicsRating;
    }

    //Setter method
    public void setGPUGraphicsRating(Graphics GPUGraphicsRating) {
        this.GPUGraphicsRating = GPUGraphicsRating;
    }
}
