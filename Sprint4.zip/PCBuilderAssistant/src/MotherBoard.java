public class MotherBoard extends Part {
    
    double pricePercentage = 0.1;

    public MotherBoard(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
