public class RAM extends Part {
    
    private int RAMGB;

    public RAM(String partName, int partPrice, int RAMGB) {
        super(partName, partPrice);
        this.RAMGB = RAMGB;
    }

    public int getRAMBG() {
        return this.RAMGB;
    }

    public void setRAMGB(int RAMGB) {
        this.RAMGB = RAMGB;
    }
}
