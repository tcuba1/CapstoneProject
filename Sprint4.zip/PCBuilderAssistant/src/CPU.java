public class CPU extends Part {
    
    double pricePercentage = 0.2;

    public CPU(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
