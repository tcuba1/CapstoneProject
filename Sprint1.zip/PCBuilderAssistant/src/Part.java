public class Part {
    //Part variables
    private int price;
    private String partName;

    //Constructor
    public Part(String partName, int price) {
        this.partName = partName;
        this.price = price;
    }

    //Getter methods
    public String getPartName() {
        return partName;
    }

    public int getPartPrice() {
        return price;
    }

    //Setter methods
    public void setPartName(String partName) {
        this.partName = partName;
    }

    public void setPartPrice(int price) {
        this.price = price;
    }
}
