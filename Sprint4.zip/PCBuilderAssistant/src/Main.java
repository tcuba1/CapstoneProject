public class Main {
    public static void main(String[] args) {

        UserInfo user = new UserInfo(0);

        user.userQuestionnaire();


        PartInventory testInventory = new PartInventory("Test Inventory");

        testInventory.loadInventory();
        System.out.println(testInventory.getRecommendedPart(user.getUserBudget()).getPartName());
        System.out.println(testInventory.getRecommendedPart(user.getUserBudget()).getPartPrice());


    }
}
