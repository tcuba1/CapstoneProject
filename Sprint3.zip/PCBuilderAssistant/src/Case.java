public class Case extends Part {
    

    public Case(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
