public class CaseFans extends Part {
    

    public CaseFans(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
