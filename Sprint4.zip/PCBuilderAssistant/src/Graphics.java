public enum Graphics {
    
    LOW, MEDIUM, HIGH;
    
}
