public class MotherBoard extends Part {
    
}
