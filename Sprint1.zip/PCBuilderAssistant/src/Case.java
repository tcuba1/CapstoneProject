public class Case extends Part {
    
}
