public class Storage extends Part {
    
    private StorageType storageType;
    public double pricePercentage = 0.15;

    public Storage(String partName, int partPrice, StorageType storageType) {
        super(partName, partPrice);
        this.storageType = storageType;
    }

    public StorageType getStorageType() {
        return this.storageType;
    }

    public void setStorageType(StorageType storageType) {
        this.storageType = storageType;
    }
}
