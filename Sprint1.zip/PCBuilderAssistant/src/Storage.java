public class Storage extends Part {
    
}
