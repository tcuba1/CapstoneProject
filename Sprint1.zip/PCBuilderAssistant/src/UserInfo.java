public class UserInfo {
    // Variables
    private int budget;
    private Graphics graphicsSelection;

    // Constructor
    public UserInfo(int budget, Graphics graphicsSelection) {
        this.budget = budget;
        this.graphicsSelection = graphicsSelection;
    }

    // Getter methods
    public int getUserBudget() {
        return budget;
    }

    public Graphics getPartPrice() {
        return graphicsSelection;
    }

    // Setter methods
    public void setUserBudget(int budget) {
        this.budget = budget;
    }

    public void setUserGraphicsSelection(Graphics graphicsSelection) {
        this.graphicsSelection = graphicsSelection;
    }
}
