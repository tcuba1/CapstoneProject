public class Case extends Part {
    
    public double pricePercentage = 0.5;

    public Case(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
