public class Main {
    public static void main(String[] args) {
        UserInfo user = new UserInfo(0);

        user.userQuestionnaire();
    }
}
