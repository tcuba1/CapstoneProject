import java.util.Scanner;

public class UserInfo {

    Scanner scanner = new Scanner(System.in);

    // Variables
    private int budget;

    private StorageType storagePreference = null;
    private Graphics graphicsPreference = null;
    private CoolingSystemType coolingSystemPreference = null;


    // Constructor
    public UserInfo(int budget) {
        this.budget = budget;
    }


    // Getter methods
    public int getUserBudget() {
        return budget;
    }

    public Graphics getUserGraphicsPrefence() {
        return graphicsPreference;
    }

    public StorageType getUserStoragePreference() {
        return storagePreference;
    }

    public CoolingSystemType getUserCoolingSystemPreference() {
        return coolingSystemPreference;
    }


    // Setter methods
    public void setUserBudget(int budget) {
        this.budget = budget;
    }

    public void setUserGraphicsPreference(Graphics graphicsPreference) {
        this.graphicsPreference = graphicsPreference;
    }

    public void setUserStoragePreference(StorageType storagePreference) {
        this.storagePreference = storagePreference;
    }

    public void setUserCoolingSystemPreference(CoolingSystemType coolingSystemPreference) {
        this.coolingSystemPreference = coolingSystemPreference;
    }


    public void userQuestionnaire() {

        System.out.println("What is your budget?");
        int userBudget = scanner.nextInt();
        setUserBudget(userBudget);

        scanner.nextLine();
        System.out.println("User budget set to: " + getUserBudget());

        System.out.println("What kind of graphics are you looking for? (low, medium, high, none):");
        String graphicsResponse = scanner.nextLine().trim().toUpperCase();

        while (true) {
            switch (graphicsResponse) {
                case "LOW":

                    setUserGraphicsPreference(Graphics.LOW);
                    break;

                case "MEDIUM":

                    setUserGraphicsPreference(Graphics.MEDIUM);
                    break;

                case "HIGH":

                    setUserGraphicsPreference(Graphics.HIGH);
                    break;

                case "NONE":

                    break;

                default:

                    System.out.println("Invalid response, try again");
                    graphicsResponse = scanner.nextLine().trim().toUpperCase();
                    continue;

            }
            break;
        }

        System.out.println("Graphics preference set to: " + getUserGraphicsPrefence());

        System.out.println("What kind of storage system do you prefer? (SSD, HDD, none):");
        String storageResponse = scanner.nextLine().trim().toUpperCase();

        while (true) {
            switch (storageResponse) {
                case "SSD":

                    setUserStoragePreference(StorageType.SSD);
                    break;

                case "HDD":

                    setUserStoragePreference(StorageType.HDD);
                    break;

                case "NONE":

                    break;

                default:

                    System.out.println("Invalid response, try again");
                    storageResponse = scanner.nextLine().trim().toUpperCase();
                    continue;

            }
            break;
        }

        System.out.println("Graphics preference set to: " + getUserStoragePreference());

        System.out.println("What kind of cooling system do you prefer? (air, liquid, none):");
        String coolingResponse = scanner.nextLine().trim().toUpperCase();

        while (true) {
            switch (coolingResponse) {
                case "AIR":

                    setUserCoolingSystemPreference(CoolingSystemType.AIR);
                    break;

                case "LIQUID":

                setUserCoolingSystemPreference(CoolingSystemType.AIOLiquidCooling);
                    break;

                case "NONE":

                    break;

                default:

                    System.out.println("Invalid response, try again");
                    coolingResponse = scanner.nextLine().trim().toUpperCase();
                    continue;

            }
            break;
        }

        System.out.println("Graphics preference set to: " + getUserCoolingSystemPreference());

    }
}
