public enum StorageType {
    
    SSD, HDD;

}
