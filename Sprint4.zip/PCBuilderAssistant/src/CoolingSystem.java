public class CoolingSystem extends Part {
    
    private CoolingSystemType coolingSystemType;
    double pricePercentage = 0.5;
   
    public CoolingSystem(String partName, int partPrice, CoolingSystemType systemType) {
        super(partName, partPrice);
        this.coolingSystemType = systemType;
    }
   
    public CoolingSystemType getCoolingSystemType() {
        return this.coolingSystemType;
    }

    public void setCoolingSystemType(CoolingSystemType systemType) {
        this.coolingSystemType = systemType;
    }
}
