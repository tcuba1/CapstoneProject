public class MotherBoard extends Part {
    

    public MotherBoard(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
