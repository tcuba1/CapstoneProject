public class CPU extends Part {
    
}
