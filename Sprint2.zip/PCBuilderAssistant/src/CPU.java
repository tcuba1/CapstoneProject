public class CPU extends Part {
    

    public CPU(String partName, int partPrice) {
        super(partName, partPrice);
    }
}
