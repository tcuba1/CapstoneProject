import java.util.ArrayList;
import java.util.List;

public class PartInventory {
    //Variables
    private String inventoryName;
    public List<Part> inventoryList = new ArrayList<>();

    //Constructor
    public PartInventory(String inventoryName) {
        this.inventoryName = inventoryName;
    }

    //Getter
    public String getInventoryName() {
        return inventoryName;
    }

    //Setter
    public void setInventoryName(String inventoryName) {
        this.inventoryName = inventoryName;
    }
    
    public void loadInventory() {
        Part testPart = new Part("Test Part", 50);
        this.inventoryList.add(testPart);
    }

    public Part getRecommendedPart(int budget) {
        Part part = new Part("part", 50);
        return part;
    }
}
