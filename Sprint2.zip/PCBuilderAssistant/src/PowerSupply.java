public class PowerSupply extends Part {
    
    private int wattage;

    public PowerSupply(String partName, int partPrice, int wattage) {
        super(partName, partPrice);
        this.wattage = wattage;
    }

    public int getWattage() {
        return this.wattage;
    }

    public void setWattage(int wattage) {
        this.wattage = wattage;
    }
}
